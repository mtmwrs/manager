#include "enigma.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <string.h>

string enigma::encrypt(string initialString, int seed){
    string result;
    for (char a : initialString) a+seed>126 ? result+=static_cast<char>(32+(a+seed-126)): result+=static_cast<char>(a+seed);
    return result;
}

string enigma::decrypt(string encryptedString, int seed){
    string result;
    for (char a : encryptedString) a-seed<32 ? result+=static_cast<char>(126-(32-a+seed)): result+=static_cast<char>(a-seed);
    return result;
}

enigma::enigma()
{
    //ctor
}

enigma::~enigma()
{
    //dtor
}
