#ifndef ENIGMA_H
#define ENIGMA_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <string.h>
using namespace std;

class enigma
{
    public:
        enigma();
        virtual ~enigma();

    static string encrypt(string initialString, int seed);

    static string decrypt(string encryptedString, int seed);

    protected:

    private:
};

#endif // ENIGMA_H
