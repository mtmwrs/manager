#include <iostream>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <cstring>
#include "enigma.cpp"
#include "enigma.h"

int main() {
    int randSeed = 4;
    string name;
    string password;
    int userSeed;
    ofstream fileWriter;
    ifstream fileReader;
    cout<<"Input your user name and password separated by enter to log in or write 'new' to sign up"<<endl;
    cin>>name;
    if (name.compare("new")==0){
        cout<<"Input your user name and password that will be used to access your data"<<endl;
        cin>>name>>password;
        fileWriter.open("userData.txt", ios_base::app);
        stringstream intToString;
        intToString << rand()%94;
        fileWriter<<enigma::encrypt(name+" "+password+" "+intToString.str(), randSeed)<<endl;
        fileWriter.close();
    }else{
        cin>>password;
        string* line = new string();
        string* decryptedLine = new string();
        string* compName = new string();
        string* compPass = new string();
        string* posSeed = new string();
        bool* isRegistred = new bool(false);
        fileReader.open("userData.txt");
        while(!(*isRegistred)&&!(fileReader.peek()==EOF)){
            getline(fileReader, *line);
            *compName=strtok(strdup((line)->c_str()), enigma::encrypt(" ", randSeed).c_str());
            *compPass=strtok(NULL, enigma::encrypt(" ", randSeed).c_str());
            *posSeed=strtok(NULL, enigma::encrypt(" ", randSeed).c_str());
            *compName=(enigma::decrypt(*compName, randSeed));
            //cout<<*compName<<" "<<name<<endl;
            if (compName->compare(name)==0){
                *compPass=(enigma::decrypt(*compPass, randSeed));
                if (compPass->compare(password)==0){
                    userSeed=stoi(enigma::decrypt(*posSeed, randSeed).c_str());
                    *isRegistred = true;
                    //delete line;
                    //delete decryptedLine;
                    //delete compName;
                    //delete compPass;
                    //delete posSeed;
                }else{
                    return -1;
                }
            }
            //fileReader.get();
        }
        fileReader.close();
        if (!(*isRegistred)) return -10;
        delete isRegistred;

        bool isDone = false;
        while(!isDone){
            cout<<"Welcome, "<<name<<". Would you like to read from your file (input 1), add to it (input 2), view all records (input 3), delete all files if FBR knocks on your door while heavily breathing (input 5) or leave (input 4)."<<endl;
            cin>>*line;
            try{
                //cout<<stoi(line->c_str())<<endl;
                switch (stoi(line->c_str())){
                    case 5:{
                        char oldname_data[] = "C:\\Users\\�����\\Desktop\\Studies\\PJC\\PasswordManager\\userData.txt";
                        char newname_data[] = "C:\\Users\\�����\\Desktop\\Studies\\PJC\\PasswordManager\\let us pretend it is recycle bin\\userData.txt";
                        char oldname_passes[] = "C:\\Users\\�����\\Desktop\\Studies\\PJC\\PasswordManager\\userPasswords.txt";
                        char newname_passes[] = "C:\\Users\\�����\\Desktop\\Studies\\PJC\\PasswordManager\\let us pretend it is recycle bin\\userPasswords.txt";
                        if (rename(oldname_data, newname_data) != 0)
                            perror("Poor country. No files, no education.");
                        else
                        if (rename(oldname_passes, newname_passes) != 0)
                            perror("Poor country. No files, no education.");
                        else
                            cout << "Rich country. Many files, great educations."<<endl;
                        break;
                    }
                    case 1:{
                        cout<<"Input name of service to show password for or input 0 to leave."<<endl;
                        bool* isDoneOne = new bool(false);
                        while(!(*isDoneOne)){
                            cin>>*line;
                                if((*line)[0]=='0'&&(line->length()==1)){
                                    *isDoneOne = true;
                                }
                                bool* isFound = new bool(false);
                                fileReader.open("userPasswords.txt");
                                while(!(fileReader.peek()==EOF)){
                                    string* temp = new string();
                                    getline(fileReader, *temp);
                                    *compName=strtok(strdup((temp)->c_str()), enigma::encrypt(" ", userSeed).c_str());
                                    *compPass=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *posSeed=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *decryptedLine=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *compPass=(enigma::decrypt(*compPass, userSeed));
                                    //cout<<*compPass<<" "<<*line<<endl;
                                    if ((compPass->compare(*line)==0)&&(enigma::decrypt(*compName, userSeed).compare(name)==0)){
                                        cout<<*compPass+" "+enigma::decrypt(*posSeed, userSeed)+" "+enigma::decrypt(*decryptedLine, userSeed)<<endl;
                                        *isFound = true;
                                    }
                                }
                                fileReader.close();
                                *isDoneOne = true;
                                if (!(*isFound)) cout<<"Nowhere to be found."<<endl;
                                //delete isFound;
                                //delete decryptedLine;
                                //delete compName;
                                //delete compPass;
                                //delete posSeed;
                                //delete line;
                            }
                            delete isDoneOne;
                        break;
                    }
                    case 2:{
                        cout<<"Input name of the service, your login and password: "<<endl;
                        cin>>*line>>*decryptedLine>>*compName;
                        fileWriter.open("userPasswords.txt", ios_base::app);
                        fileWriter<<enigma::encrypt(name+" "+*line+" "+*decryptedLine+" "+*compName, userSeed)<<endl;
                        fileWriter.close();
                        break;
                    }
                    case 3:{
                        fileReader.open("userPasswords.txt");
                        while(!(fileReader.peek()==EOF)){
                                    string* temp = new string();
                                    getline(fileReader, *temp);
                                    *compName=strtok(strdup((temp)->c_str()), enigma::encrypt(" ", userSeed).c_str());
                                    *compPass=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *posSeed=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *decryptedLine=strtok(NULL, enigma::encrypt(" ", userSeed).c_str());
                                    *compPass=(enigma::decrypt(*compPass, userSeed));
                                    //cout<<*compPass<<" "<<*line<<endl;
                                    if (enigma::decrypt(*compName, userSeed).compare(name)==0){
                                        cout<<*compPass+" "+enigma::decrypt(*posSeed, userSeed)+" "+enigma::decrypt(*decryptedLine, userSeed)<<endl;
                                    }
                                }
                                fileReader.close();
                        break;
                    }
                    case 4:{
                        return 0;
                        break;
                    }

                }
            }catch(invalid_argument &e){
                cout<<"error "<<e.what()<<endl;
            }
        }
    }
}

